var express = require('express');
var router = express.Router();

/* GET users listing. */
router.get('/', function(req, res, next) {
  res.send('respond with a resource');
});

//SIGNUP
router.get('/signup', function(req, res, next){
  res.render('signup')
});

router.post('/signup', function(req, res, next) {
  models.users.findOrCreate({
    where: {
      UserName: req.body.username
    },
    defaults : {
      FirstName: req.body.firstName,
      LastName: req.body.lastName,
      Email: req.body.email,
      Password: authService.hashPassword(req.body.password)
    }
  }).spread(function(result, created){
    if(created){
      res.redirect('/login');
    }else{
      res.send('A user with this username already exists');
    }
  })
});

//LOG IN:
router.get('/login', function(req, res, next) {
  res.render('login');
});




module.exports = router;
