var express = require('express');
var router = express.Router();
var models = require('../models')
/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express' });
});

//POSTS
router.get('/posts', function(req, res, next){
  models.posts.findAll({}).then(foundPosts => {
    const mappedPosts = foundPosts.map(post => ({
      PostId: post.PostId,
      PostTitle: post.PostTitle,
      Description: post.Description,
      Username: post.Username
    }));
    res.send(JSON.stringify(mappedPosts));
  });
});


module.exports = router;
