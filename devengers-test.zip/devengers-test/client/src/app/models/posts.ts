export class Post{
  PostId: number;
  PostTitle: string;
  Description: string;
  Username: string;
  Date: Date
}
