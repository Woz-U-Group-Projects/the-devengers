export class User {
    userid: number;
    firstname: string;
    lastname: string;
    email: string;
    username: string;
    password: string;
    level: string;
}
