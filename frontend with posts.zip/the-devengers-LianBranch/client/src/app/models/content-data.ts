export class ContentData {
    PostId: number;
    PostTitle: string;
    Description: string;
    Username: string;
}
