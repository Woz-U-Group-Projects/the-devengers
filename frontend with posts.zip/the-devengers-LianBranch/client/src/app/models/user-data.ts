export class UserData {
    id: number;
    name: string;
    username: string;
    email: string;
    password: string;
    phone: number;
}
