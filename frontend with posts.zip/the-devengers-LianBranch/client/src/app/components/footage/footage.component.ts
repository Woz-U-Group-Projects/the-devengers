import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-footage',
  templateUrl: './footage.component.html',
  styleUrls: ['./footage.component.css']
})
export class FootageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
